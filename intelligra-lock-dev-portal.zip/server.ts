/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { OnboardingSession, DeviceState, ApiLog, Country } from './src/types';

// In-Memory Simulation Database
const countries: Country[] = [
  { code: 'rw', name: 'Rwanda' },
  { code: 'tz', name: 'Tanzania' },
  { code: 'ke', name: 'Kenya' },
  { code: 'ug', name: 'Uganda' },
  { code: 'ng', name: 'Nigeria' },
  { code: 'za', name: 'South Africa' },
  { code: 'gh', name: 'Ghana' },
  { code: 'et', name: 'Ethiopia' },
];

let sessions: OnboardingSession[] = [
  {
    sessionId: '3b5d4336-7813-40e8-b1ee-b4734e7188a7',
    username: 'bbox_tz_user',
    countryCode: 'tz',
    msisdn: '06811037699',
    serviceProvider: 'ttp',
    imei: '861166080008862',
    useMobileData: true,
    status: 'PENDING',
    createdAt: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
    completedAt: null,
  },
  {
    sessionId: 'cb5cf099-b44b-498c-9b28-fc77f4d15865',
    username: 'telecom_rw_agent',
    countryCode: 'rw',
    msisdn: '0788123456',
    serviceProvider: 'knox-g',
    imei: '356271702410769',
    useMobileData: false,
    wifiSSID: 'Intelligra-Office',
    wifiPassword: 'Password123',
    wifiSecType: 'WPA2',
    status: 'COMPLETED',
    createdAt: new Date(Date.now() - 7200000).toISOString(), // 2 hours ago
    completedAt: new Date(Date.now() - 7100000).toISOString(),
  }
];

let devices: DeviceState[] = [
  {
    imei: '356271702410769',
    isLocked: true,
    status: 'LOCKED',
    countryCode: 'rw',
    lastUpdated: new Date(Date.now() - 7100000).toISOString(),
  },
  {
    imei: '354433651262011',
    isLocked: true,
    status: 'LOCKED',
    countryCode: 'rw',
    lastUpdated: new Date(Date.now() - 15000000).toISOString(),
  },
  {
    imei: '353818875200071',
    isLocked: false,
    status: 'UNLOCKED',
    countryCode: 'rw',
    lastUpdated: new Date(Date.now() - 5000000).toISOString(),
  },
  {
    imei: '354933910525348',
    isLocked: false,
    status: 'UNLOCKED',
    countryCode: 'tz',
    lastUpdated: new Date(Date.now() - 8000000).toISOString(),
  },
  {
    imei: '861166080008862',
    isLocked: false,
    status: 'PENDING_ONBOARDING',
    countryCode: 'tz',
    lastUpdated: new Date(Date.now() - 3600000).toISOString(),
  }
];

let apiLogs: ApiLog[] = [];

function addApiLog(
  method: string,
  endpoint: string,
  headers: Record<string, string>,
  requestBody: any,
  responseStatus: number,
  responseBody: any,
  durationMs: number
) {
  const log: ApiLog = {
    id: 'log_' + Math.random().toString(36).substr(2, 9),
    timestamp: new Date().toISOString(),
    method,
    endpoint,
    headers,
    requestBody,
    responseStatus,
    responseBody,
    durationMs,
  };
  apiLogs.unshift(log); // Keep latest logs at the top
  if (apiLogs.length > 100) apiLogs.pop(); // Max 100 logs
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Simple Request Logger to inspect and mirror requests
  app.use((req, res, next) => {
    const startTime = Date.now();
    const originalSend = res.send;
    let responseBody: any;

    res.send = function (body) {
      try {
        responseBody = JSON.parse(body);
      } catch (e) {
        responseBody = body;
      }
      return originalSend.apply(res, arguments as any);
    };

    res.on('finish', () => {
      // Exclude logs internal routes from being self-logged to avoid recursion loops
      if (!req.path.startsWith('/api/internal/')) {
        const duration = Date.now() - startTime;
        // Extract relevant headers
        const logHeaders: Record<string, string> = {};
        if (req.headers['client-id']) logHeaders['client-id'] = req.headers['client-id'] as string;
        if (req.headers['client-secret']) logHeaders['client-secret'] = req.headers['client-secret'] as string;
        if (req.headers['content-type']) logHeaders['content-type'] = req.headers['content-type'] as string;

        addApiLog(
          req.method,
          req.path,
          logHeaders,
          req.body && Object.keys(req.body).length > 0 ? req.body : undefined,
          res.statusCode,
          responseBody,
          duration
        );
      }
    });

    next();
  });

  // Client authentication check middleware (for simulated API security)
  const validateApiCredentials = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const clientId = req.headers['client-id'];
    const clientSecret = req.headers['client-secret'];

    if (!clientId || !clientSecret) {
      return res.status(401).json({
        status: 'error',
        message: 'Unauthorized: Missing Client-Id or Client-Secret headers.',
        code: '401'
      });
    }
    next();
  };

  // --- INTERNAL CONSOLE API ---
  // To allow the React Dashboard to log in, clear, reset and monitor the server state

  // Login handler
  app.post('/api/internal/login', (req, res) => {
    const { username, password } = req.body;
    if (username === 'Nuddy' && password === 'Kigali@05') {
      res.json({
        status: 'success',
        token: 'intelligra-jwt-session-token-nuddy-2026',
        user: { username: 'Nuddy', role: 'Administrator' }
      });
    } else {
      res.status(401).json({
        status: 'error',
        message: 'Invalid username or password'
      });
    }
  });

  // Fetch all devices (Internal State Monitor)
  app.get('/api/internal/devices', (req, res) => {
    res.json(devices);
  });

  // Fetch all onboarding sessions (Internal State Monitor)
  app.get('/api/internal/sessions', (req, res) => {
    res.json(sessions);
  });

  // Fetch logs (Internal State Monitor)
  app.get('/api/internal/logs', (req, res) => {
    res.json(apiLogs);
  });

  // Proxy route for real live Intelligra API to bypass browser CORS
  app.post('/api/internal/proxy', async (req, res) => {
    const { path: apiPath, method, headers, body } = req.body;
    if (!apiPath) {
      return res.status(400).json({ status: 'error', message: 'API path is required for proxying.' });
    }

    const targetUrl = `https://dev-api-lock.intelligra.io/api${apiPath}`;
    const startTime = Date.now();

    try {
      const options: RequestInit = {
        method: method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Client-Id': headers?.['Client-Id'] || req.headers['client-id'] || '',
          'Client-Secret': headers?.['Client-Secret'] || req.headers['client-secret'] || '',
        }
      };

      if (method === 'POST' && body) {
        options.body = typeof body === 'string' ? body : JSON.stringify(body);
      }

      const response = await fetch(targetUrl, options);
      const text = await response.text();
      const duration = Date.now() - startTime;

      let responseData: any;
      try {
        responseData = JSON.parse(text);
      } catch (e) {
        responseData = text;
      }

      // Add to logs terminal with a clear "LIVE" label
      addApiLog(
        method || 'GET',
        `[REAL-LIVE-API] ${apiPath}`,
        {
          'client-id': (options.headers as Record<string, string>)['Client-Id'],
          'client-secret': '***masked***',
          'content-type': 'application/json'
        },
        body,
        response.status,
        responseData,
        duration
      );

      res.status(response.status).json(responseData);
    } catch (err: any) {
      const duration = Date.now() - startTime;
      res.status(500).json({
        status: 'error',
        message: `Failed to proxy request to Intelligra server: ${err.message || 'Unknown error'}`,
        code: '500'
      });
    }
  });

  // Clear logs (Internal State Monitor)
  app.post('/api/internal/logs/clear', (req, res) => {
    apiLogs = [];
    res.json({ status: 'success', message: 'Logs cleared successfully' });
  });

  // Reset simulator state (Internal State Monitor)
  app.post('/api/internal/reset', (req, res) => {
    sessions = [
      {
        sessionId: '3b5d4336-7813-40e8-b1ee-b4734e7188a7',
        username: 'bbox_tz_user',
        countryCode: 'tz',
        msisdn: '06811037699',
        serviceProvider: 'ttp',
        imei: '861166080008862',
        useMobileData: true,
        status: 'PENDING',
        createdAt: new Date().toISOString(),
        completedAt: null,
      }
    ];
    devices = [
      {
        imei: '356271702410769',
        isLocked: true,
        status: 'LOCKED',
        countryCode: 'rw',
        lastUpdated: new Date().toISOString(),
      },
      {
        imei: '354433651262011',
        isLocked: true,
        status: 'LOCKED',
        countryCode: 'rw',
        lastUpdated: new Date().toISOString(),
      },
      {
        imei: '353818875200071',
        isLocked: false,
        status: 'UNLOCKED',
        countryCode: 'rw',
        lastUpdated: new Date().toISOString(),
      },
      {
        imei: '354933910525348',
        isLocked: false,
        status: 'UNLOCKED',
        countryCode: 'tz',
        lastUpdated: new Date().toISOString(),
      }
    ];
    apiLogs = [];
    res.json({ status: 'success', message: 'Simulator state reset successfully' });
  });

  // Allow manual state injection from the React UI (e.g. creating/deleting a device)
  app.post('/api/internal/devices/add', (req, res) => {
    const { imei, isLocked, status, countryCode } = req.body;
    if (!imei) return res.status(400).json({ status: 'error', message: 'IMEI is required' });

    // Check if duplicate imei
    if (devices.some(d => d.imei === imei)) {
      return res.status(400).json({ status: 'error', message: 'Device with this IMEI already exists' });
    }

    const newDevice: DeviceState = {
      imei,
      isLocked: !!isLocked,
      status: status || (isLocked ? 'LOCKED' : 'UNLOCKED'),
      countryCode: countryCode || 'rw',
      lastUpdated: new Date().toISOString()
    };
    devices.push(newDevice);
    res.json({ status: 'success', data: newDevice });
  });


  // --- OFFICIAL SIMULATED API ENDPOINTS (AS SPECIFIED IN POSTMAN COLLECTION) ---

  // 1. start-onboarding-session
  // POST /onboarding/start-new-session
  app.post('/onboarding/start-new-session', validateApiCredentials, (req, res) => {
    const { username, countryCode, msisdn, serviceProvider, imei, wifiSSID, wifiPassword, wifiSecType, useMobileData } = req.body;

    if (!username || !countryCode || !msisdn || !serviceProvider || useMobileData === undefined) {
      return res.status(400).json({
        status: 'error',
        message: 'Bad Request: Missing required fields (username, countryCode, msisdn, serviceProvider, useMobileData).',
        code: '400'
      });
    }

    // Check if session or device already exists for this IMEI to match Apidog behavior
    if (imei) {
      const existingSession = sessions.find(s => s.imei === imei);
      if (existingSession) {
        return res.status(400).json({
          status: 'error',
          message: 'Session for device already exists',
          code: '09',
          data: {
            sessionId: existingSession.sessionId,
            imei: existingSession.imei,
            msisdn: existingSession.msisdn,
            provider: existingSession.serviceProvider,
            qrCode: null
          },
          extraData: null
        });
      }

      const existingDevice = devices.find(d => d.imei === imei);
      if (existingDevice) {
        return res.status(400).json({
          status: 'error',
          message: 'Session for device already exists',
          code: '09',
          data: {
            sessionId: 'fab52139-f540-45fa-add6-020d99befaad',
            imei: imei,
            msisdn: msisdn || '06811037699',
            provider: serviceProvider || 'ttp',
            qrCode: null
          },
          extraData: null
        });
      }
    }

    const sessionId = 'session_' + Math.random().toString(36).substr(2, 9) + '-' + Math.random().toString(36).substr(2, 4);

    const newSession: OnboardingSession = {
      sessionId,
      username,
      countryCode,
      msisdn,
      serviceProvider,
      imei,
      wifiSSID,
      wifiPassword,
      wifiSecType,
      useMobileData,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
      completedAt: null
    };

    sessions.push(newSession);

    // If IMEI was supplied, make sure it is registered in pending onboarding state
    if (imei && !devices.some(d => d.imei === imei)) {
      devices.push({
        imei,
        isLocked: false,
        status: 'PENDING_ONBOARDING',
        countryCode,
        lastUpdated: new Date().toISOString()
      });
    }

    res.json({
      status: 'success',
      message: 'Onboarding session started successfully',
      code: '00',
      data: {
        sessionId
      }
    });
  });

  // 2. get-onboarding-status
  // GET /onboarding/get-device-onboarding-status?sessionId=...&debug=false
  app.get('/onboarding/get-device-onboarding-status', validateApiCredentials, (req, res) => {
    const { sessionId, debug } = req.query;

    if (!sessionId) {
      return res.status(400).json({
        status: 'error',
        message: 'Bad Request: Missing sessionId parameter.',
        code: '400'
      });
    }

    const session = sessions.find(s => s.sessionId === sessionId);

    if (!session) {
      return res.status(500).json({
        status: 'error',
        message: 'Object reference not set to an instance of an object.',
        code: '97',
        data: null
      });
    }

    res.json({
      status: 'success',
      message: 'Session status retrieved',
      code: '00',
      data: {
        sessionId: session.sessionId,
        status: session.status,
        username: session.username,
        imei: session.imei || null,
        createdAt: session.createdAt,
        completedAt: session.completedAt
      }
    });
  });

  // 3. get-supporting-countries
  // GET /onboarding/get-countries
  app.get('/onboarding/get-countries', validateApiCredentials, (req, res) => {
    res.json({
      status: 'success',
      message: 'Countries retrieved',
      code: '00',
      data: countries
    });
  });

  // 4. complete-onboarding
  // POST /onboarding/complete-onboarding
  app.post('/onboarding/complete-onboarding', validateApiCredentials, (req, res) => {
    const { sessionId } = req.body;

    if (!sessionId) {
      return res.status(400).json({
        status: 'error',
        message: 'Bad Request: Missing sessionId.',
        code: '400'
      });
    }

    const sessionIndex = sessions.findIndex(s => s.sessionId === sessionId);

    if (sessionIndex === -1) {
      return res.status(500).json({
        status: 'error',
        message: 'Object reference not set to an instance of an object.',
        code: '97',
        data: null
      });
    }

    sessions[sessionIndex].status = 'COMPLETED';
    sessions[sessionIndex].completedAt = new Date().toISOString();

    const imei = sessions[sessionIndex].imei;
    if (imei) {
      const deviceIndex = devices.findIndex(d => d.imei === imei);
      if (deviceIndex !== -1) {
        devices[deviceIndex].status = 'UNLOCKED';
        devices[deviceIndex].isLocked = false;
        devices[deviceIndex].lastUpdated = new Date().toISOString();
      } else {
        devices.push({
          imei,
          isLocked: false,
          status: 'UNLOCKED',
          countryCode: sessions[sessionIndex].countryCode,
          lastUpdated: new Date().toISOString()
        });
      }
    }

    res.json({
      status: 'success',
      message: 'Onboarding completed successfully',
      code: '00',
      data: {
        sessionId,
        imei: imei || null,
        status: 'COMPLETED'
      }
    });
  });

  // 5. lock-device
  // POST /device-state/lock-device
  app.post('/device-state/lock-device', validateApiCredentials, (req, res) => {
    const { imei, date, time, cancelFutureLock, countryCode } = req.body;

    if (!imei) {
      return res.status(400).json({
        status: 'error',
        message: 'Bad Request: Missing imei.',
        code: '400'
      });
    }

    const deviceIndex = devices.findIndex(d => d.imei === imei);
    const country = countryCode || 'rw';

    const isImmediate = !date && !time;

    if (deviceIndex !== -1) {
      if (isImmediate) {
        devices[deviceIndex].isLocked = true;
        devices[deviceIndex].status = 'LOCKED';
        devices[deviceIndex].scheduledLockDate = null;
        devices[deviceIndex].scheduledLockTime = null;
      } else {
        devices[deviceIndex].scheduledLockDate = date || null;
        devices[deviceIndex].scheduledLockTime = time || null;
      }
      devices[deviceIndex].cancelFutureLock = !!cancelFutureLock;
      devices[deviceIndex].lastUpdated = new Date().toISOString();
    } else {
      // Create new device record
      devices.push({
        imei,
        isLocked: isImmediate,
        status: isImmediate ? 'LOCKED' : 'UNLOCKED',
        countryCode: country,
        lastUpdated: new Date().toISOString(),
        scheduledLockDate: date || null,
        scheduledLockTime: time || null,
        cancelFutureLock: !!cancelFutureLock
      });
    }

    res.json({
      status: 'success',
      message: isImmediate ? 'Device locked successfully' : 'Lock scheduled successfully',
      code: '00',
      data: {
        imei,
        isLocked: isImmediate ? true : devices.find(d => d.imei === imei)?.isLocked || false,
        lockedAt: isImmediate ? new Date().toISOString() : null,
        scheduledLock: !isImmediate ? { date: date || null, time: time || null } : null
      }
    });
  });

  // 6. device-status
  // GET /device-state/get-device-status?imei=...&debug=false
  app.get('/device-state/get-device-status', validateApiCredentials, (req, res) => {
    const { imei, debug } = req.query;

    if (!imei) {
      return res.status(400).json({
        status: 'error',
        message: 'Bad Request: Missing imei parameter.',
        code: '400'
      });
    }

    // AUTHENTIC FEATURE: Check if user wants to debug / simulate the 500 error from the Postman collection
    if (debug === 'true' || imei === '352316839630641') {
      return res.status(500).json({
        status: 'error',
        message: 'Object reference not set to an instance of an object.',
        code: '97',
        data: null
      });
    }

    const device = devices.find(d => d.imei === imei);

    if (!device) {
      return res.status(500).json({
        status: 'error',
        message: 'Object reference not set to an instance of an object.',
        code: '97',
        data: null
      });
    }

    res.json({
      status: 'success',
      message: 'Device status retrieved',
      code: '00',
      data: {
        imei: device.imei,
        isLocked: device.isLocked,
        status: device.status,
        countryCode: device.countryCode,
        lastUpdated: device.lastUpdated,
        scheduledLockDate: device.scheduledLockDate || null,
        scheduledLockTime: device.scheduledLockTime || null
      }
    });
  });

  // 7. permanently-open-device
  // POST /device-state/permanently-open-device
  app.post('/device-state/permanently-open-device', validateApiCredentials, (req, res) => {
    const { imei } = req.body;

    if (!imei) {
      return res.status(400).json({
        status: 'error',
        message: 'Bad Request: Missing imei.',
        code: '400'
      });
    }

    const deviceIndex = devices.findIndex(d => d.imei === imei);

    if (deviceIndex !== -1) {
      devices[deviceIndex].isLocked = false;
      devices[deviceIndex].status = 'UNLOCKED';
      devices[deviceIndex].scheduledLockDate = null;
      devices[deviceIndex].scheduledLockTime = null;
      devices[deviceIndex].lastUpdated = new Date().toISOString();
    } else {
      // Create record
      devices.push({
        imei,
        isLocked: false,
        status: 'UNLOCKED',
        countryCode: 'rw',
        lastUpdated: new Date().toISOString()
      });
    }

    res.json({
      status: 'success',
      message: 'Device permanently opened successfully',
      code: '00',
      data: {
        imei,
        isLocked: false
      }
    });
  });

  // 8. delete-device
  // POST /device-state/delete-device
  app.post('/device-state/delete-device', validateApiCredentials, (req, res) => {
    const { imei } = req.body;

    if (!imei) {
      return res.status(400).json({
        status: 'error',
        message: 'Bad Request: Missing imei.',
        code: '400'
      });
    }

    const deviceExists = devices.some(d => d.imei === imei);

    if (!deviceExists) {
      return res.status(500).json({
        status: 'error',
        message: 'Object reference not set to an instance of an object.',
        code: '97',
        data: null
      });
    }

    // Remove device from list
    devices = devices.filter(d => d.imei !== imei);

    res.json({
      status: 'success',
      message: 'Device data purged successfully',
      code: '00',
      data: {
        imei
      }
    });
  });

  // --- VITE MIDDLEWARE SETUP ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
