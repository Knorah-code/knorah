/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';
import { motion } from 'motion/react';
import { DeviceState, ApiLog, EndpointDefinition } from '../types';
import DeviceSimulator from './DeviceSimulator';
import LogTerminal from './LogTerminal';
import IntegrationGuide from './IntegrationGuide';
import EndpointTab from './EndpointTab';
import { 
  ShieldCheck, 
  Terminal, 
  Code, 
  Smartphone, 
  Cpu, 
  LogOut, 
  Sliders, 
  RefreshCw, 
  Key, 
  Server, 
  Activity, 
  ShieldAlert, 
  CheckCircle,
  Clock
} from 'lucide-react';

// Static Endpoint Definitions reflecting the uploaded Postman Collection JSON exactly
const ENDPOINTS: EndpointDefinition[] = [
  {
    id: 'start-onboarding-session',
    name: 'Start Onboarding Session',
    method: 'POST',
    path: '/onboarding/start-new-session',
    description: 'Start a new onboarding session for a client box device. Checks mobile data availability and registers IMEI.',
    category: 'Onboarding',
    defaultHeaders: [
      { key: 'Client-Id', value: '{{client-id}}', description: 'API Authentication Client ID' },
      { key: 'Client-Secret', value: '{{client-secret}}', description: 'API Authentication Client Secret' }
    ],
    defaultBody: JSON.stringify({
      username: "bbox",
      countryCode: "rw",
      msisdn: "06811037699",
      serviceProvider: "ttp",
      imei: "861166080008862",
      wifiSSID: "",
      wifiPassword: "",
      wifiSecType: "",
      useMobileData: true
    }, null, 2)
  },
  {
    id: 'get-onboarding-status',
    name: 'Get Onboarding Status',
    method: 'GET',
    path: '/onboarding/get-device-onboarding-status',
    description: 'Retrieve real-time onboarding status using a session ID. Checks completion state.',
    category: 'Onboarding',
    defaultHeaders: [
      { key: 'Client-Id', value: '{{client-id}}', description: 'API Authentication Client ID' },
      { key: 'Client-Secret', value: '{{client-secret}}', description: 'API Authentication Client Secret' }
    ],
    defaultQueryParams: [
      { key: 'sessionId', value: '3b5d4336-7813-40e8-b1ee-b4734e7188a7', description: 'The unique session GUID returned when starting onboarding' },
      { key: 'debug', value: 'false', description: 'Whether to enable server side debug response logging' }
    ]
  },
  {
    id: 'get-supporting-countries',
    name: 'Get Supporting Countries',
    method: 'GET',
    path: '/onboarding/get-countries',
    description: 'Query list of supporting countries where lock service operations are globally integrated.',
    category: 'Onboarding',
    defaultHeaders: [
      { key: 'Client-Id', value: '{{client-id}}', description: 'API Authentication ID' },
      { key: 'Client-Secret', value: '{{client-secret}}', description: 'API Authentication Secret' }
    ]
  },
  {
    id: 'complete-onboarding',
    name: 'Complete Onboarding',
    method: 'POST',
    path: '/onboarding/complete-onboarding',
    description: 'Commit and complete an onboarding session, permanently registering the hardware device.',
    category: 'Onboarding',
    defaultHeaders: [
      { key: 'Client-Id', value: '{{client-id}}', description: 'API Authentication Client ID' },
      { key: 'Client-Secret', value: '{{client-secret}}', description: 'API Authentication Client Secret' }
    ],
    defaultBody: JSON.stringify({
      sessionId: "cb5cf099-b44b-498c-9b28-fc77f4d15865"
    }, null, 2)
  },
  {
    id: 'lock-device',
    name: 'Remote Lock Device',
    method: 'POST',
    path: '/device-state/lock-device',
    description: 'Sends lock signals to target device. Supports immediate lock or scheduling locks for specific dates.',
    category: 'Device State',
    defaultHeaders: [
      { key: 'Client-Id', value: '{{client-id}}', description: 'API Authentication ID' },
      { key: 'Client-Secret', value: '{{client-secret}}', description: 'API Authentication Secret' }
    ],
    defaultBody: JSON.stringify({
      imei: "356271702410769",
      date: "2026-06-25",
      time: "01:30",
      cancelFutureLock: false,
      countryCode: "rw"
    }, null, 2)
  },
  {
    id: 'device-status',
    name: 'Get Device Lock Status',
    method: 'GET',
    path: '/device-state/get-device-status',
    description: 'Query detailed remote hardware status including current lock flags, countries and schedules.',
    category: 'Device State',
    defaultHeaders: [
      { key: 'Client-Id', value: '{{client-id}}', description: 'API Authentication Client ID' },
      { key: 'Client-Secret', value: '{{client-secret}}', description: 'API Authentication Client Secret' }
    ],
    defaultQueryParams: [
      { key: 'imei', value: '354433651262011', description: '15 digit IMEI number' },
      { key: 'debug', value: 'false', description: 'Set to true to test simulated server-side exception recovery (Returns error code 97)' }
    ]
  },
  {
    id: 'permanently-open-device',
    name: 'Permanently Open Device',
    method: 'POST',
    path: '/device-state/permanently-open-device',
    description: 'Issues permanent open clearance signal to device, unlocking its locks entirely.',
    category: 'Device State',
    defaultHeaders: [
      { key: 'Client-Id', value: '{{client-id}}', description: 'API Authentication Client ID' },
      { key: 'Client-Secret', value: '{{client-secret}}', description: 'API Authentication Client Secret' }
    ],
    defaultBody: JSON.stringify({
      imei: "353818875200071"
    }, null, 2)
  },
  {
    id: 'delete-device',
    name: 'Delete Device (Purge)',
    method: 'POST',
    path: '/device-state/delete-device',
    description: 'Purges a devices history and records permanently from the remote lock service.',
    category: 'Device State',
    defaultHeaders: [
      { key: 'Client-Id', value: '{{client-id}}', description: 'API Authentication ID' },
      { key: 'Client-Secret', value: '{{client-secret}}', description: 'API Authentication Secret' }
    ],
    defaultBody: JSON.stringify({
      imei: "354933910525348"
    }, null, 2)
  }
];

interface DashboardProps {
  user: { username: string; role: string };
  onLogout: () => void;
}

export default function Dashboard({ user, onLogout }: DashboardProps) {
  const [activeTab, setActiveTab] = useState<'explorer' | 'devices' | 'logs' | 'docs'>('explorer');
  const [clientId, setClientId] = useState('dc2c6126-cc95-4806-9064-bb523c312674');
  const [clientSecret, setClientSecret] = useState('8l_$0IjH)jG*hOqGfWiRDYMEFhL0DcJP');
  const [showCredsDrawer, setShowCredsDrawer] = useState(false);

  // Simulated Database states (mirrored from backend)
  const [devices, setDevices] = useState<DeviceState[]>([]);
  const [logs, setLogs] = useState<ApiLog[]>([]);
  const [isResetting, setIsResetting] = useState(false);

  // Sync / Fetch State from Backend
  const fetchBackendState = useCallback(async () => {
    try {
      const [devRes, logRes] = await Promise.all([
        fetch('/api/internal/devices'),
        fetch('/api/internal/logs')
      ]);

      if (devRes.ok) {
        const devData = await devRes.json();
        setDevices(devData);
      }
      if (logRes.ok) {
        const logData = await logRes.json();
        setLogs(logData);
      }
    } catch (e) {
      console.error('Failed to sync backend simulator state:', e);
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchBackendState();
  }, [fetchBackendState]);

  const handleResetSimulator = async () => {
    if (!confirm('This will purge all custom devices, registered sessions, and log histories back to default. Proceed?')) return;
    setIsResetting(true);
    try {
      const res = await fetch('/api/internal/reset', { method: 'POST' });
      if (res.ok) {
        fetchBackendState();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsResetting(false);
    }
  };

  const handleClearLogs = async () => {
    try {
      const res = await fetch('/api/internal/logs/clear', { method: 'POST' });
      if (res.ok) {
        setLogs([]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Derive Statistics
  const totalDevices = devices.length;
  const lockedDevices = devices.filter(d => d.status === 'LOCKED').length;
  const pendingOnboardings = devices.filter(d => d.status === 'PENDING_ONBOARDING').length;

  return (
    <div id="portal-dashboard" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Top Navigation Header */}
      <header className="bg-slate-900 border-b border-slate-800 px-6 py-4 sticky top-0 z-50 shadow-md backdrop-blur-md bg-slate-900/90">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          
          {/* Branding */}
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-blue-600 to-indigo-500 rounded-lg text-white shadow shadow-blue-500/20">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-display font-bold tracking-tight text-white">
                  Intelligra Lock Dev Portal
                </h1>
                <span className="text-[9px] uppercase font-mono px-2 py-0.5 rounded bg-blue-600/10 text-blue-400 border border-blue-500/20 font-bold">
                  SIMULATOR v2.1
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium mt-0.5">
                Full-Stack Integration Hub for remote locking & onboarding services
              </p>
            </div>
          </div>

          {/* Controls / Session info */}
          <div className="flex items-center gap-3 flex-wrap">
            
            {/* Credentials toggle button */}
            <button
              onClick={() => setShowCredsDrawer(!showCredsDrawer)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                showCredsDrawer 
                  ? 'bg-blue-600/10 border-blue-500/30 text-blue-400' 
                  : 'bg-slate-850 hover:bg-slate-800 border-slate-800 text-slate-300'
              }`}
            >
              <Key className="w-3.5 h-3.5" /> API Keys
            </button>

            {/* Reset simulator */}
            <button
              onClick={handleResetSimulator}
              disabled={isResetting}
              title="Reset Simulated DB State"
              className="p-2 bg-slate-850 hover:bg-red-950/40 border border-slate-800 hover:border-red-900/40 text-slate-400 hover:text-red-400 rounded-lg text-xs transition-all cursor-pointer flex items-center gap-1 font-mono disabled:opacity-40"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isResetting ? 'animate-spin' : ''}`} />
            </button>

            {/* User credentials panel */}
            <div className="h-8 pl-3 border-l border-slate-800 flex items-center gap-3">
              <div className="text-right">
                <p className="text-xs font-semibold text-slate-200">{user.username}</p>
                <p className="text-[9px] text-slate-500 font-mono font-bold uppercase">{user.role}</p>
              </div>
              <button
                onClick={onLogout}
                className="p-2 bg-slate-850 hover:bg-slate-800 hover:text-red-400 rounded-lg text-slate-400 transition-colors cursor-pointer"
                title="Log out of console"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>
      </header>

      {/* Collapsible Credentials & Endpoint Settings Panel */}
      {showCredsDrawer && (
        <motion.div
          id="credentials-drawer"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="bg-slate-900 border-b border-slate-800/80 px-6 py-5 relative z-40 shadow-inner"
        >
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-blue-500" />
                Auth Token Configurations
              </h4>
              <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
                Configure your mock keys. Removing or modifying these will emulate credential validation failures (401 Unauthorized), which helps verify how your production clients handle authentication errors.
              </p>
            </div>

            <div>
              <label className="block text-[10px] text-slate-400 font-mono uppercase font-bold mb-1.5">
                Client-Id Header (Dynamic)
              </label>
              <div className="relative">
                <Key className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-600" />
                <input
                  type="text"
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-850 rounded-lg text-xs font-mono text-slate-300 focus:outline-none focus:border-blue-500"
                  placeholder="No client-id configured"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] text-slate-400 font-mono uppercase font-bold mb-1.5">
                Client-Secret Header (Dynamic)
              </label>
              <div className="relative">
                <Key className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-600" />
                <input
                  type="password"
                  value={clientSecret}
                  onChange={(e) => setClientSecret(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-850 rounded-lg text-xs font-mono text-slate-300 focus:outline-none focus:border-blue-500"
                  placeholder="No client-secret configured"
                />
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Main Stats / Indicators bar */}
      <section className="bg-slate-900/30 border-b border-slate-900 px-6 py-6">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          
          {/* Stat 1: Connection status */}
          <div className="p-4 bg-slate-900/60 border border-slate-850 rounded-xl flex items-center gap-3.5">
            <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 shrink-0">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Simulator Endpoint</span>
              <p className="text-xs font-bold text-slate-200 mt-0.5 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-ping" />
                Connected (Local)
              </p>
            </div>
          </div>

          {/* Stat 2: Total Registered Devices */}
          <div className="p-4 bg-slate-900/60 border border-slate-850 rounded-xl flex items-center gap-3.5">
            <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400 shrink-0">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Registry Size</span>
              <p className="text-sm font-display font-extrabold text-slate-100 mt-0.5">
                {totalDevices} Devices
              </p>
            </div>
          </div>

          {/* Stat 3: Locked Devices */}
          <div className="p-4 bg-slate-900/60 border border-slate-850 rounded-xl flex items-center gap-3.5">
            <div className="p-2.5 rounded-lg bg-red-500/10 text-red-400 shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Locked Terminals</span>
              <p className="text-sm font-display font-extrabold text-slate-100 mt-0.5">
                {lockedDevices} Locked
              </p>
            </div>
          </div>

          {/* Stat 4: Pending Onboardings */}
          <div className="p-4 bg-slate-900/60 border border-slate-850 rounded-xl flex items-center gap-3.5">
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Pending Onboards</span>
              <p className="text-sm font-display font-extrabold text-slate-100 mt-0.5">
                {pendingOnboardings} Sessions
              </p>
            </div>
          </div>

        </div>
      </section>

      {/* Main Workspace Tabs */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 space-y-6">
        
        {/* Tab switcher buttons */}
        <div className="flex border-b border-slate-800 pb-px gap-2">
          <button
            onClick={() => setActiveTab('explorer')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all flex items-center gap-2 border-b-2 cursor-pointer ${
              activeTab === 'explorer'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="w-4 h-4" /> API Explorer
          </button>

          <button
            onClick={() => setActiveTab('devices')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all flex items-center gap-2 border-b-2 cursor-pointer ${
              activeTab === 'devices'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-4 h-4" /> Device Simulator & Overrides
          </button>

          <button
            onClick={() => setActiveTab('logs')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all flex items-center gap-2 border-b-2 cursor-pointer ${
              activeTab === 'logs'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-4 h-4" /> Live Gateway Logs
          </button>

          <button
            onClick={() => setActiveTab('docs')}
            className={`px-4 py-2.5 text-xs font-semibold transition-all flex items-center gap-2 border-b-2 cursor-pointer ${
              activeTab === 'docs'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code className="w-4 h-4" /> Integration Guide (SDKs)
          </button>
        </div>

        {/* Dynamic Tab Workspace Container */}
        <section id="workspace-container" className="pt-2">
          {activeTab === 'explorer' && (
            <EndpointTab
              endpoints={ENDPOINTS}
              clientId={clientId}
              clientSecret={clientSecret}
              onSuccessTrigger={fetchBackendState}
            />
          )}

          {activeTab === 'devices' && (
            <DeviceSimulator
              devices={devices}
              onRefresh={fetchBackendState}
              clientId={clientId}
              clientSecret={clientSecret}
            />
          )}

          {activeTab === 'logs' && (
            <LogTerminal
              logs={logs}
              onClear={handleClearLogs}
              onRefresh={fetchBackendState}
            />
          )}

          {activeTab === 'docs' && (
            <IntegrationGuide
              endpoints={ENDPOINTS}
              clientId={clientId}
              clientSecret={clientSecret}
            />
          )}
        </section>

      </main>

      {/* Footer copyright */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-[11px] text-slate-600 font-mono tracking-wider">
        © 2026 INTELLIGRA GLOBAL REMOTE LOCK SERVICES • PRE-DEPLOYED SDK SANDBOX
      </footer>

    </div>
  );
}
