/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { EndpointDefinition } from '../types';
import { Terminal, Copy, Check, FileText, Code2, Globe } from 'lucide-react';

interface IntegrationGuideProps {
  endpoints: EndpointDefinition[];
  clientId: string;
  clientSecret: string;
}

export default function IntegrationGuide({ endpoints, clientId, clientSecret }: IntegrationGuideProps) {
  const [selectedEndpointId, setSelectedEndpointId] = useState(endpoints[0]?.id || '');
  const [activeTab, setActiveTab] = useState<'curl' | 'node' | 'python' | 'go'>('curl');
  const [copied, setCopied] = useState(false);

  const endpoint = endpoints.find(e => e.id === selectedEndpointId) || endpoints[0];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getCurlCode = () => {
    if (!endpoint) return '';
    const headersStr = endpoint.defaultHeaders
      .map(h => {
        const val = h.key === 'Client-Id' ? clientId : h.key === 'Client-Secret' ? clientSecret : h.value;
        return `-H "${h.key}: ${val}"`;
      })
      .join(' \\\n  ');

    const host = window.location.origin;

    if (endpoint.method === 'GET') {
      const qParams = endpoint.defaultQueryParams
        ? '?' + endpoint.defaultQueryParams.map(qp => `${qp.key}=${qp.value}`).join('&')
        : '';
      return `curl -X GET "${host}${endpoint.path}${qParams}" \\\n  ${headersStr}`;
    } else {
      return `curl -X POST "${host}${endpoint.path}" \\\n  ${headersStr} \\\n  -d '${endpoint.defaultBody || '{}'}'`;
    }
  };

  const getNodeCode = () => {
    if (!endpoint) return '';
    const host = window.location.origin;
    const cleanPath = endpoint.path;

    const headersObj: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    endpoint.defaultHeaders.forEach(h => {
      headersObj[h.key] = h.key === 'Client-Id' ? clientId : h.key === 'Client-Secret' ? clientSecret : h.value;
    });

    const options: any = {
      method: endpoint.method,
      headers: headersObj,
    };

    if (endpoint.method === 'POST') {
      options.body = JSON.parse(endpoint.defaultBody || '{}');
    }

    return `// Install cross-fetch if running in node env: npm install cross-fetch
import fetch from 'cross-fetch';

async function fireRequest() {
  const url = '${host}${cleanPath}${endpoint.method === 'GET' && endpoint.defaultQueryParams ? '?' + endpoint.defaultQueryParams.map(qp => `${qp.key}=${qp.value}`).join('&') : ''}';
  
  const response = await fetch(url, {
    method: '${endpoint.method}',
    headers: ${JSON.stringify(headersObj, null, 4)} ${endpoint.method === 'POST' ? `,` : ''}
    ${endpoint.method === 'POST' ? `body: JSON.stringify(${JSON.stringify(options.body, null, 4).replace(/\n/g, '\n    ')})` : ''}
  });

  const data = await response.json();
  console.log('API Response:', data);
}

fireRequest().catch(console.error);`;
  };

  const getPythonCode = () => {
    if (!endpoint) return '';
    const host = window.location.origin;
    const headersObj: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    endpoint.defaultHeaders.forEach(h => {
      headersObj[h.key] = h.key === 'Client-Id' ? clientId : h.key === 'Client-Secret' ? clientSecret : h.value;
    });

    const paramsStr = endpoint.defaultQueryParams
      ? `params = {\n${endpoint.defaultQueryParams.map(qp => `    "${qp.key}": "${qp.value}"`).join(',\n')}\n}`
      : 'params = {}';

    const bodyStr = endpoint.method === 'POST'
      ? `payload = ${endpoint.defaultBody?.replace(/true/g, 'True').replace(/false/g, 'False').replace(/null/g, 'None') || '{}'}`
      : 'payload = {}';

    return `import requests

url = "${host}${endpoint.path}"

headers = {
${Object.entries(headersObj).map(([k, v]) => `    "${k}": "${v}"`).join(',\n')}
}

${endpoint.method === 'GET' ? paramsStr : bodyStr}

response = requests.${endpoint.method.toLowerCase()}(
    url,
    headers=headers,
    ${endpoint.method === 'GET' ? 'params=params' : 'json=payload'}
)

print("Status Code:", response.status_code)
print("JSON Response:", response.json())`;
  };

  const getGoCode = () => {
    if (!endpoint) return '';
    const host = window.location.origin;
    const bodyDeclare = endpoint.method === 'POST'
      ? `\tpayload := strings.NewReader(\`${endpoint.defaultBody || '{}'}\`)\n`
      : '';

    const reqInstantiation = endpoint.method === 'POST'
      ? `\treq, err := http.NewRequest("POST", url, payload)`
      : `\treq, err := http.NewRequest("GET", url, nil)`;

    const queryAddStr = endpoint.defaultQueryParams
      ? `\tq := req.URL.Query()\n` + endpoint.defaultQueryParams.map(qp => `\tq.Add("${qp.key}", "${qp.value}")`).join('\n') + `\n\treq.URL.RawQuery = q.Encode()\n`
      : '';

    return `package main

import (
\t"fmt"
\t"io"
\t"net/http"
${endpoint.method === 'POST' ? `\t"strings"\n` : ''})

func main() {
\turl := "${host}${endpoint.path}"

${bodyDeclare}${reqInstantiation}
\tif err != nil {
\t\tpanic(err)
\t}

\treq.Header.Add("Content-Type", "application/json")
\treq.Header.Add("Client-Id", "${clientId}")
\treq.Header.Add("Client-Secret", "${clientSecret}")

${queryAddStr}
\tres, err := http.DefaultClient.Do(req)
\tif err != nil {
\t\tpanic(err)
\t}
\tdefer res.Body.Close()

\tbody, _ := io.ReadAll(res.Body)
\tfmt.Println(res.Status)
\tfmt.Println(string(body))
}`;
  };

  const getActiveCode = () => {
    switch (activeTab) {
      case 'curl': return getCurlCode();
      case 'node': return getNodeCode();
      case 'python': return getPythonCode();
      case 'go': return getGoCode();
    }
  };

  return (
    <div id="integration-guide-panel" className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl grid grid-cols-1 md:grid-cols-4 min-h-[500px]">
      
      {/* Endpoint Selector Column */}
      <div className="border-r border-slate-800 p-4 bg-slate-900/50 space-y-3">
        <h3 className="text-xs font-mono font-bold uppercase text-slate-400 tracking-wider flex items-center gap-1.5 pb-2 border-b border-slate-800/60">
          <FileText className="w-4 h-4 text-blue-500" />
          Endpoints Reference
        </h3>
        <div className="space-y-1">
          {endpoints.map((ep) => (
            <button
              key={ep.id}
              onClick={() => setSelectedEndpointId(ep.id)}
              className={`w-full text-left p-2.5 rounded-lg text-xs transition-all flex flex-col gap-1 cursor-pointer ${
                selectedEndpointId === ep.id
                  ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-1.5">
                <span className={`px-1.5 py-0.5 rounded-[3px] text-[8px] font-bold ${
                  ep.method === 'POST' ? 'bg-indigo-600/20 text-indigo-400' : 'bg-blue-600/20 text-blue-400'
                }`}>
                  {ep.method}
                </span>
                <span className="font-semibold truncate font-sans">{ep.name}</span>
              </div>
              <span className="text-[10px] text-slate-500 truncate font-mono">{ep.path}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Snippet Viewer Column */}
      <div className="md:col-span-3 flex flex-col">
        {/* Tab Selector Bar */}
        <div className="bg-slate-900/80 px-4 py-2 border-b border-slate-800 flex flex-wrap justify-between items-center gap-3">
          <div className="flex gap-1.5">
            {([
              { id: 'curl', label: 'cURL / Shell' },
              { id: 'node', label: 'NodeJS Fetch' },
              { id: 'python', label: 'Python (requests)' },
              { id: 'go', label: 'Go Native' }
            ] as const).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-slate-850 text-slate-100 border border-slate-700/60 shadow'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850/50 border border-transparent'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => handleCopy(getActiveCode())}
            className="p-1.5 bg-slate-950 border border-slate-800 hover:border-slate-700 hover:bg-slate-900 text-slate-400 hover:text-slate-200 rounded-lg text-xs transition-all flex items-center gap-1.5 cursor-pointer font-mono"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied!
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" /> Copy Code
              </>
            )}
          </button>
        </div>

        {/* Dynamic Code Pre Block */}
        <div className="flex-1 bg-slate-950 p-5 relative overflow-auto custom-scrollbar font-mono text-[11px] text-slate-300 leading-relaxed min-h-[350px]">
          <div className="absolute top-4 right-4 bg-slate-900 border border-slate-800 rounded-md px-2 py-1 text-[10px] font-mono text-slate-500 flex items-center gap-1">
            <Code2 className="w-3 h-3 text-indigo-400" />
            {activeTab.toUpperCase()}
          </div>
          <pre className="select-all block pr-12 whitespace-pre">
            {getActiveCode()}
          </pre>
        </div>

        {/* Quick Instructions Bottom Bar */}
        <div className="bg-slate-900 p-4 border-t border-slate-800 text-xs text-slate-400 flex items-start gap-3">
          <Terminal className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-slate-300">Integration Notes</p>
            <p className="text-[11px] mt-1 text-slate-400/80">
              The headers <code>Client-Id</code> and <code>Client-Secret</code> are parsed server-side to validate your security schema. You can dynamically adjust these in the top settings panel of the playground to generate custom integration tokens. Ensure you replace local URLs with your global production endpoints.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
