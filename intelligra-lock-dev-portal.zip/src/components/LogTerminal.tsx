/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { ApiLog } from '../types';
import { Terminal, Trash2, ChevronDown, ChevronRight, Clock, ShieldCheck, ShieldAlert, Cpu, Search, CheckCircle, AlertOctagon } from 'lucide-react';

interface LogTerminalProps {
  logs: ApiLog[];
  onClear: () => void;
  onRefresh: () => void;
}

export default function LogTerminal({ logs, onClear, onRefresh }: LogTerminalProps) {
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMethod, setFilterMethod] = useState<'ALL' | 'GET' | 'POST'>('ALL');

  // Poll logs list more aggressively for live feedback
  useEffect(() => {
    const interval = setInterval(() => {
      onRefresh();
    }, 1500);
    return () => clearInterval(interval);
  }, [onRefresh]);

  const toggleExpand = (id: string) => {
    setExpandedLogId(expandedLogId === id ? null : id);
  };

  const filteredLogs = logs.filter((log) => {
    const matchesSearch = log.endpoint.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          log.method.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          String(log.responseStatus).includes(searchTerm);
    const matchesMethod = filterMethod === 'ALL' ? true : log.method === filterMethod;
    return matchesSearch && matchesMethod;
  });

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'text-emerald-400 bg-emerald-500/10 border-emerald-900/30';
    if (status >= 400 && status < 500) return 'text-amber-400 bg-amber-500/10 border-amber-900/30';
    return 'text-red-400 bg-red-500/10 border-red-900/30';
  };

  return (
    <div id="log-terminal-panel" className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden font-mono text-xs flex flex-col h-[650px] shadow-2xl">
      {/* Terminal Header */}
      <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="flex gap-1.5">
            <span className="w-3 h-3 rounded-full bg-red-500/85 inline-block" />
            <span className="w-3 h-3 rounded-full bg-amber-500/85 inline-block" />
            <span className="w-3 h-3 rounded-full bg-emerald-500/85 inline-block" />
          </div>
          <span className="text-slate-400 font-semibold text-xs tracking-wider flex items-center gap-1.5 pl-2 border-l border-slate-800">
            <Terminal className="w-4 h-4 text-blue-400" />
            Intelligra Gateway Simulation Logs
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onClear}
            className="text-[11px] text-slate-400 hover:text-red-400 flex items-center gap-1.5 bg-slate-850 px-2 py-1 rounded border border-slate-800 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" /> Clear logs
          </button>
        </div>
      </div>

      {/* Terminal Controls Bar */}
      <div className="p-3 bg-slate-900/40 border-b border-slate-800/80 flex flex-col md:flex-row items-center gap-3 justify-between">
        {/* Search */}
        <div className="relative w-full md:w-72">
          <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-slate-600">
            <Search className="w-3.5 h-3.5" />
          </span>
          <input
            type="text"
            placeholder="Filter endpoint, status..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-300 placeholder-slate-700 focus:outline-none focus:border-slate-700 transition-colors"
          />
        </div>

        {/* Method filter tabs */}
        <div className="flex gap-1.5 self-stretch md:self-auto justify-end">
          {(['ALL', 'GET', 'POST'] as const).map((method) => (
            <button
              key={method}
              onClick={() => setFilterMethod(method)}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                filterMethod === method
                  ? 'bg-blue-600/10 text-blue-400 border-blue-500/20'
                  : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300'
              }`}
            >
              {method}
            </button>
          ))}
        </div>
      </div>

      {/* Logs stream area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2.5 custom-scrollbar bg-slate-950">
        {filteredLogs.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-600 gap-2 py-20">
            <Cpu className="w-8 h-8 text-slate-800 animate-pulse" />
            <p className="font-sans text-xs">Waiting for incoming API requests...</p>
            <p className="font-sans text-[11px] text-slate-700">Go to API Explorer to issue live calls.</p>
          </div>
        ) : (
          filteredLogs.map((log) => {
            const isExpanded = expandedLogId === log.id;
            const isSuccess = log.responseStatus >= 200 && log.responseStatus < 300;

            return (
              <div
                key={log.id}
                className={`rounded-lg border transition-all ${
                  isExpanded
                    ? 'bg-slate-900/60 border-slate-800 shadow-lg'
                    : 'bg-slate-900/20 border-slate-900/40 hover:bg-slate-900/30 hover:border-slate-800/40'
                }`}
              >
                {/* Row Header */}
                <div
                  onClick={() => toggleExpand(log.id)}
                  className="px-3 py-2.5 flex flex-wrap items-center justify-between gap-3 cursor-pointer select-none"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] text-slate-600 font-mono">
                      {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </span>

                    {/* Method Badge */}
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono border ${
                      log.method === 'POST' 
                        ? 'bg-indigo-600/15 text-indigo-400 border-indigo-500/20' 
                        : 'bg-blue-600/15 text-blue-400 border-blue-500/20'
                    }`}>
                      {log.method}
                    </span>

                    {/* Endpoint */}
                    <span className="text-slate-300 font-semibold font-mono tracking-wide">
                      {log.endpoint}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    {/* Duration Badge */}
                    <span className="text-slate-600 font-mono text-[10px] flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-700" /> {log.durationMs}ms
                    </span>

                    {/* Status Code badge */}
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono border flex items-center gap-1 ${getStatusColor(log.responseStatus)}`}>
                      {isSuccess ? <CheckCircle className="w-3 h-3" /> : <AlertOctagon className="w-3 h-3" />}
                      {log.responseStatus}
                    </span>

                    {isExpanded ? <ChevronDown className="w-4 h-4 text-slate-500" /> : <ChevronRight className="w-4 h-4 text-slate-600" />}
                  </div>
                </div>

                {/* Expanded Details Area */}
                {isExpanded && (
                  <div className="px-4 pb-4 pt-2 border-t border-slate-800/60 bg-slate-950/60 rounded-b-lg space-y-4">
                    {/* Headers Sub-section */}
                    <div>
                      <h4 className="text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                        <Cpu className="w-3.5 h-3.5 text-slate-600" />
                        Request Headers Received
                      </h4>
                      <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-900 space-y-1 text-slate-400 font-mono text-[11px]">
                        {Object.entries(log.headers).length === 0 ? (
                          <span className="text-slate-700 italic">No custom credentials supplied</span>
                        ) : (
                          Object.entries(log.headers).map(([k, v]) => (
                            <p key={k}>
                              <span className="text-slate-600">{k}:</span>{' '}
                              <span className="text-indigo-400">
                                {k.toLowerCase().includes('secret') ? '••••••••••••••••' : v}
                              </span>
                            </p>
                          ))
                        )}
                      </div>
                    </div>

                    {/* Body Section */}
                    {log.requestBody && (
                      <div>
                        <h4 className="text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1.5">
                          Payload Parameters (Request Body)
                        </h4>
                        <pre className="bg-slate-950 p-3 rounded-lg border border-slate-900 text-amber-400 overflow-x-auto text-[11px] leading-relaxed select-all max-h-48 scrollbar">
                          {JSON.stringify(log.requestBody, null, 2)}
                        </pre>
                      </div>
                    )}

                    {/* Response Body Section */}
                    <div>
                      <h4 className="text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                        {isSuccess ? (
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                        ) : (
                          <ShieldAlert className="w-3.5 h-3.5 text-red-500" />
                        )}
                        Simulated Response Body
                      </h4>
                      <pre className={`bg-slate-950 p-3 rounded-lg border border-slate-900 overflow-x-auto text-[11px] leading-relaxed select-all max-h-60 scrollbar ${
                        isSuccess ? 'text-emerald-400' : 'text-red-400'
                      }`}>
                        {JSON.stringify(log.responseBody, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Terminal Footer status */}
      <div className="bg-slate-900 px-4 py-2 border-t border-slate-800 text-[10px] text-slate-500 flex justify-between items-center">
        <span>STATUS: ACTIVE STREAMING LISTENER</span>
        <span>INTELLIGRA CONSOLE v2.1</span>
      </div>
    </div>
  );
}
