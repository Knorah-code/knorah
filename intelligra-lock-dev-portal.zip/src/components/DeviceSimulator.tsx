/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { DeviceState } from '../types';
import { Smartphone, ShieldAlert, ShieldCheck, RefreshCw, Plus, Trash2, Globe, Lock, Unlock, Calendar, Clock, AlertTriangle } from 'lucide-react';

interface DeviceSimulatorProps {
  devices: DeviceState[];
  onRefresh: () => void;
  clientId: string;
  clientSecret: string;
}

export default function DeviceSimulator({ devices, onRefresh, clientId, clientSecret }: DeviceSimulatorProps) {
  const [newImei, setNewImei] = useState('');
  const [newCountry, setNewCountry] = useState('rw');
  const [newStatus, setNewStatus] = useState<'LOCKED' | 'UNLOCKED' | 'PENDING_ONBOARDING'>('UNLOCKED');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Auto-refresh devices list every 4 seconds to catch active onboarding completions
  useEffect(() => {
    const interval = setInterval(() => {
      onRefresh();
    }, 4000);
    return () => clearInterval(interval);
  }, [onRefresh]);

  const handleCreateDevice = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!/^\d{15}$/.test(newImei)) {
      setErrorMsg('IMEI must be exactly 15 numeric digits.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/internal/devices/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imei: newImei,
          isLocked: newStatus === 'LOCKED',
          status: newStatus,
          countryCode: newCountry
        })
      });

      const data = await res.json();
      if (res.ok && data.status === 'success') {
        setSuccessMsg(`Device IMEI ${newImei} successfully provisioned.`);
        setNewImei('');
        onRefresh();
      } else {
        setErrorMsg(data.message || 'Failed to create device.');
      }
    } catch (err) {
      setErrorMsg('Network error while provisioning device.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRemoteTriggerLock = async (imei: string, shouldLock: boolean) => {
    setActionLoading(imei);
    setErrorMsg(null);
    setSuccessMsg(null);

    const url = shouldLock ? '/device-state/lock-device' : '/device-state/permanently-open-device';
    const body = shouldLock 
      ? { imei, date: null, time: null, cancelFutureLock: false, countryCode: 'rw' }
      : { imei };

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Client-Id': clientId,
          'Client-Secret': clientSecret
        },
        body: JSON.stringify(body)
      });

      const data = await res.json();
      if (res.ok && data.status === 'success') {
        setSuccessMsg(`Remote signal sent: IMEI ${imei} is now ${shouldLock ? 'LOCKED' : 'UNLOCKED'}.`);
        onRefresh();
      } else {
        setErrorMsg(data.message || 'Operation rejected by simulator core.');
      }
    } catch (err) {
      setErrorMsg('Network error while firing lock/unlock trigger.');
    } finally {
      setActionLoading(null);
    }
  };

  const handleDeleteDevice = async (imei: string) => {
    if (!confirm(`Are you sure you want to permanently delete device ${imei} from the registry?`)) return;
    setActionLoading(imei);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const res = await fetch('/device-state/delete-device', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Client-Id': clientId,
          'Client-Secret': clientSecret
        },
        body: JSON.stringify({ imei })
      });

      const data = await res.json();
      if (res.ok && data.status === 'success') {
        setSuccessMsg(`Device data for IMEI ${imei} purged.`);
        onRefresh();
      } else {
        setErrorMsg(data.message || 'Failed to delete device.');
      }
    } catch (err) {
      setErrorMsg('Network error while requesting device deletion.');
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <div id="device-simulator-panel" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Devices Grid State */}
      <div className="lg:col-span-2 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-display font-semibold text-slate-100 flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-blue-500" />
              Live Simulated Devices State ({devices.length})
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Real-time hardware visualization. Use client credentials to execute actions or override locks.
            </p>
          </div>
          <button
            onClick={onRefresh}
            className="p-2 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 transition-colors flex items-center gap-2 text-xs font-medium cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Refresh
          </button>
        </div>

        {/* Feedback Area */}
        {errorMsg && (
          <div className="p-3 bg-red-950/40 border border-red-800/60 rounded-lg text-xs text-red-400 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg text-xs text-emerald-400 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <AnimatePresence mode="popLayout">
            {devices.map((device) => (
              <motion.div
                key={device.imei}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={`p-4 rounded-xl border relative overflow-hidden flex flex-col justify-between h-56 transition-all ${
                  device.status === 'LOCKED'
                    ? 'bg-slate-900/90 border-red-900/50 shadow-md shadow-red-900/10'
                    : device.status === 'PENDING_ONBOARDING'
                    ? 'bg-slate-900/90 border-amber-900/50 shadow-md shadow-amber-900/10'
                    : 'bg-slate-900/90 border-slate-800/80'
                }`}
              >
                {/* Visual indicator bar */}
                <div className={`absolute top-0 inset-x-0 h-1 ${
                  device.status === 'LOCKED'
                    ? 'bg-red-500'
                    : device.status === 'PENDING_ONBOARDING'
                    ? 'bg-amber-500'
                    : 'bg-emerald-500'
                }`} />

                {/* Device Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-lg ${
                      device.status === 'LOCKED'
                        ? 'bg-red-500/10 text-red-400'
                        : device.status === 'PENDING_ONBOARDING'
                        ? 'bg-amber-500/10 text-amber-400'
                        : 'bg-emerald-500/10 text-emerald-400'
                    }`}>
                      <Smartphone className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs font-mono font-bold text-slate-200 tracking-wider">
                        IMEI: {device.imei}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 flex items-center gap-1">
                          <Globe className="w-3 h-3 text-blue-500" /> {device.countryCode}
                        </span>
                        {device.scheduledLockDate && (
                          <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-purple-950/40 text-purple-400 border border-purple-900/40 flex items-center gap-1">
                            <Clock className="w-3 h-3" /> Scheduled
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <span className={`text-[10px] font-bold px-2 py-1 rounded-full uppercase ${
                    device.status === 'LOCKED'
                      ? 'bg-red-500/15 text-red-400 border border-red-500/20'
                      : device.status === 'PENDING_ONBOARDING'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/20 animate-pulse'
                      : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                  }`}>
                    {device.status.replace('_', ' ')}
                  </span>
                </div>

                {/* Device Middle State Description */}
                <div className="my-3 text-xs text-slate-400">
                  {device.status === 'LOCKED' ? (
                    <p className="flex items-center gap-1.5 text-red-300/85">
                      <ShieldAlert className="w-4 h-4 text-red-500 shrink-0" />
                      Locked. Access to operations is locked.
                    </p>
                  ) : device.status === 'PENDING_ONBOARDING' ? (
                    <p className="flex items-center gap-1.5 text-amber-300/85">
                      <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                      Onboarding requested. Waiting complete-onboarding signal.
                    </p>
                  ) : (
                    <p className="flex items-center gap-1.5 text-emerald-300/85">
                      <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                      Open. Device is fully unlocked and operating.
                    </p>
                  )}
                  {device.scheduledLockDate && (
                    <div className="mt-2 pl-5 text-[11px] text-purple-300/70 space-y-0.5">
                      <p className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-purple-400" /> Date: {device.scheduledLockDate}
                      </p>
                      <p className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-purple-400" /> Time: {device.scheduledLockTime || 'Immediate'}
                      </p>
                    </div>
                  )}
                </div>

                {/* Device Actions */}
                <div className="border-t border-slate-800/80 pt-3 flex items-center justify-between gap-2">
                  <div className="flex gap-2">
                    {device.status === 'LOCKED' ? (
                      <button
                        onClick={() => handleRemoteTriggerLock(device.imei, false)}
                        disabled={actionLoading === device.imei}
                        className="px-2.5 py-1.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-850 text-emerald-300 hover:text-emerald-200 rounded-md text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Unlock className="w-3 h-3" /> Unlock Device
                      </button>
                    ) : (
                      <button
                        onClick={() => handleRemoteTriggerLock(device.imei, true)}
                        disabled={actionLoading === device.imei || device.status === 'PENDING_ONBOARDING'}
                        className="px-2.5 py-1.5 bg-red-950 hover:bg-red-900 border border-red-850 text-red-300 hover:text-red-200 rounded-md text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                      >
                        <Lock className="w-3 h-3" /> Lock Device
                      </button>
                    )}
                  </div>

                  <button
                    onClick={() => handleDeleteDevice(device.imei)}
                    disabled={actionLoading === device.imei}
                    title="Purge device from system"
                    className="p-1.5 bg-slate-850 hover:bg-red-950/40 text-slate-400 hover:text-red-400 rounded border border-slate-850 hover:border-red-900/30 transition-all cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Manual Device Injector */}
      <div className="space-y-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-lg">
          <h3 className="text-sm font-display font-bold text-slate-100 flex items-center gap-2 pb-3 border-b border-slate-800/80 mb-4">
            <Plus className="w-4.5 h-4.5 text-blue-500" />
            Provision Manual Test Device
          </h3>

          <form onSubmit={handleCreateDevice} className="space-y-4">
            <div>
              <label className="block text-[11px] text-slate-400 font-mono font-semibold uppercase mb-1.5">
                IMEI (15 Digits)
              </label>
              <input
                type="text"
                maxLength={15}
                required
                value={newImei}
                onChange={(e) => setNewImei(e.target.value.replace(/\D/g, ''))}
                placeholder="e.g. 354433651262011"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 font-mono placeholder-slate-700 focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 font-mono font-semibold uppercase mb-1.5">
                  Country Code
                </label>
                <select
                  value={newCountry}
                  onChange={(e) => setNewCountry(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-blue-500 transition-colors"
                >
                  <option value="rw">Rwanda (rw)</option>
                  <option value="tz">Tanzania (tz)</option>
                  <option value="ke">Kenya (ke)</option>
                  <option value="ug">Uganda (ug)</option>
                  <option value="ng">Nigeria (ng)</option>
                  <option value="za">South Africa (za)</option>
                  <option value="gh">Ghana (gh)</option>
                  <option value="et">Ethiopia (et)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 font-mono font-semibold uppercase mb-1.5">
                  Initial Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-blue-500 transition-colors"
                >
                  <option value="UNLOCKED">Unlocked</option>
                  <option value="LOCKED">Locked</option>
                  <option value="PENDING_ONBOARDING">Pending Onboard</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 text-white font-medium rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 mt-2 shadow-md shadow-blue-500/10"
            >
              {isSubmitting ? 'Provisioning...' : 'Provision Test Device'}
            </button>
          </form>
        </div>

        {/* Informative Help Guide Card */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 text-xs text-slate-400 space-y-2.5">
          <h4 className="font-display font-semibold text-slate-300">Lock Service Simulation Info</h4>
          <p>
            When you fire requests in the <strong>API Explorer</strong>, the results are directly reflected in this device status panel.
          </p>
          <ul className="list-disc pl-4 space-y-1.5 font-sans text-[11px]">
            <li>
              Triggering <code>/onboarding/start-new-session</code> registers the device as <strong>Pending Onboarding</strong>.
            </li>
            <li>
              Calling <code>/onboarding/complete-onboarding</code> converts the device state to <strong>Unlocked</strong>.
            </li>
            <li>
              Sending <code>/device-state/lock-device</code> shuts down accessibility immediately (re-locking the device).
            </li>
            <li>
              Toggling <strong>Debug 500 Simulation</strong> on requests allows testing how client apps recover from authentic backend exceptions (returns custom error code 97).
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
