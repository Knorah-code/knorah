/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { EndpointDefinition } from '../types';
import { Play, Clipboard, Check, AlertCircle, Sparkles, Send, ArrowRight, CornerDownRight, Settings, Globe, Calendar, Clock } from 'lucide-react';

interface EndpointTabProps {
  endpoints: EndpointDefinition[];
  clientId: string;
  clientSecret: string;
  onSuccessTrigger: () => void; // Trigger device refresh
}

export default function EndpointTab({ endpoints, clientId, clientSecret, onSuccessTrigger }: EndpointTabProps) {
  const [selectedEpId, setSelectedEpId] = useState(endpoints[0]?.id || '');
  const [environment, setEnvironment] = useState<'simulated' | 'live'>('simulated');
  const [queryParams, setQueryParams] = useState<Record<string, string>>({});
  const [jsonBody, setJsonBody] = useState('');
  const [isRawBody, setIsRawBody] = useState(false);

  // References to programmatically trigger date/time picker
  const dateInputRef = useRef<HTMLInputElement | null>(null);
  const timeInputRef = useRef<HTMLInputElement | null>(null);
  
  // Response state
  const [isLoading, setIsLoading] = useState(false);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseTime, setResponseTime] = useState<number | null>(null);
  const [responseHeaders, setResponseHeaders] = useState<Record<string, string>>({});
  const [responseBody, setResponseBody] = useState<any>(null);
  const [copied, setCopied] = useState(false);

  // Form Fields mapped (for user-friendly edits)
  const [formFields, setFormFields] = useState<Record<string, any>>({});

  const endpoint = endpoints.find(e => e.id === selectedEpId) || endpoints[0];

  // Sync fields when endpoint changes
  useEffect(() => {
    if (!endpoint) return;

    // Reset query params
    const qps: Record<string, string> = {};
    if (endpoint.defaultQueryParams) {
      endpoint.defaultQueryParams.forEach(qp => {
        qps[qp.key] = qp.value;
      });
    }
    setQueryParams(qps);

    // Reset Body
    setJsonBody(endpoint.defaultBody || '');

    // Reset friendly form fields
    if (endpoint.defaultBody) {
      try {
        const parsed = JSON.parse(endpoint.defaultBody);
        setFormFields(parsed);
      } catch (e) {
        setFormFields({});
      }
    } else {
      setFormFields({});
    }

    // Reset responses
    setResponseStatus(null);
    setResponseBody(null);
    setResponseTime(null);
  }, [selectedEpId]);

  // Sync raw JSON body when form fields change (if in form mode)
  useEffect(() => {
    if (!isRawBody && Object.keys(formFields).length > 0) {
      setJsonBody(JSON.stringify(formFields, null, 2));
    }
  }, [formFields, isRawBody]);

  const handleFormFieldChange = (key: string, val: any) => {
    setFormFields(prev => ({
      ...prev,
      [key]: val === 'true' ? true : val === 'false' ? false : val === 'null' ? null : val
    }));
  };

  const handleFireRequest = async () => {
    setIsLoading(true);
    setResponseStatus(null);
    setResponseBody(null);
    setResponseTime(null);

    const startTime = Date.now();
    let url: string;
    let options: RequestInit;

    if (environment === 'live') {
      url = `${window.location.origin}/api/internal/proxy`;
      const qKeys = Object.keys(queryParams);
      const queryStr = qKeys.length > 0 
        ? '?' + qKeys.map(k => `${encodeURIComponent(k)}=${encodeURIComponent(queryParams[k])}`).join('&')
        : '';

      let payload: any = null;
      if (endpoint.method === 'POST') {
        try {
          payload = JSON.parse(jsonBody);
        } catch (e) {
          payload = jsonBody;
        }
      }

      options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Client-Id': clientId,
          'Client-Secret': clientSecret
        },
        body: JSON.stringify({
          path: `${endpoint.path}${queryStr}`,
          method: endpoint.method,
          headers: {
            'Client-Id': clientId,
            'Client-Secret': clientSecret
          },
          body: payload
        })
      };
    } else {
      // Construct final URL
      const baseUrl = window.location.origin;
      url = `${baseUrl}${endpoint.path}`;

      // Append query params
      const qKeys = Object.keys(queryParams);
      if (qKeys.length > 0) {
        const qString = qKeys
          .map(k => `${encodeURIComponent(k)}=${encodeURIComponent(queryParams[k])}`)
          .join('&');
        url += `?${qString}`;
      }

      // Set custom headers
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'Client-Id': clientId,
        'Client-Secret': clientSecret
      };

      options = {
        method: endpoint.method,
        headers
      };

      if (endpoint.method === 'POST') {
        options.body = jsonBody;
      }
    }

    try {
      const res = await fetch(url, options);
      const duration = Date.now() - startTime;
      
      const text = await res.text();
      let parsedBody: any;
      try {
        parsedBody = JSON.parse(text);
      } catch (e) {
        parsedBody = text;
      }

      setResponseStatus(res.status);
      setResponseTime(duration);
      setResponseBody(parsedBody);

      // Collect some headers for visual play
      const head: Record<string, string> = {
        'Content-Type': res.headers.get('content-type') || 'application/json',
        'Server': environment === 'live' ? 'Intelligra API Server' : 'Nginx/Simulated (Intelligra Cloud)',
        'X-Powered-By': environment === 'live' ? 'Intelligra Core Gateway' : 'Express.js Node API Engine'
      };
      setResponseHeaders(head);

      // Trigger successful mutations refresh (like device state list)
      onSuccessTrigger();
    } catch (err: any) {
      const duration = Date.now() - startTime;
      setResponseStatus(0);
      setResponseTime(duration);
      setResponseBody({
        status: 'error',
        message: err.message || 'Failed to communicate with API server.',
        hint: 'Check that the portal dev server is running and accessible.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyResponse = () => {
    if (!responseBody) return;
    navigator.clipboard.writeText(JSON.stringify(responseBody, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Elite user experience helper triggers (Auto-routing returned data)
  const renderResponseHelpers = () => {
    if (!responseBody || responseStatus !== 200) return null;

    // Helper 1: Session Id generated
    if (responseBody?.data?.sessionId) {
      const sid = responseBody.data.sessionId;
      return (
        <div className="p-3 bg-blue-950/40 border border-blue-900/50 rounded-lg text-xs text-blue-300 flex flex-wrap items-center justify-between gap-2">
          <span className="flex items-center gap-1.5 font-sans">
            <Sparkles className="w-4 h-4 text-blue-400 shrink-0" />
            Session ID generated: <code className="bg-blue-950 px-1.5 py-0.5 rounded font-bold text-white select-all">{sid}</code>
          </span>
          <div className="flex gap-2">
            <button
              onClick={() => {
                // Route to Onboarding Status
                setSelectedEpId('get-onboarding-status');
                setQueryParams({ sessionId: sid, debug: 'false' });
              }}
              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-[11px] rounded transition-colors flex items-center gap-1 font-sans font-medium cursor-pointer"
            >
              Verify Status <ArrowRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => {
                // Route to Complete Onboarding
                setSelectedEpId('complete-onboarding');
                setJsonBody(JSON.stringify({ sessionId: sid }, null, 2));
                setFormFields({ sessionId: sid });
              }}
              className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] rounded transition-colors flex items-center gap-1 font-sans font-medium cursor-pointer"
            >
              Complete Onboarding <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      );
    }

    // Helper 2: Device lock IMEI action
    if (responseBody?.data?.imei && selectedEpId === 'lock-device') {
      const im = responseBody.data.imei;
      return (
        <div className="p-3 bg-amber-950/40 border border-amber-900/50 rounded-lg text-xs text-amber-300 flex items-center justify-between gap-2">
          <span className="flex items-center gap-1.5 font-sans">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            Lock triggered on IMEI: <code className="bg-amber-950 px-1.5 py-0.5 rounded font-bold text-white select-all">{im}</code>
          </span>
          <button
            onClick={() => {
              setSelectedEpId('device-status');
              setQueryParams({ imei: im, debug: 'false' });
            }}
            className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white text-[11px] rounded transition-colors flex items-center gap-1 font-sans font-medium cursor-pointer"
          >
            Check Lock Status <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      );
    }

    return null;
  };

  return (
    <div id="api-explorer-panel" className="grid grid-cols-1 xl:grid-cols-2 gap-6">
      
      {/* LEFT COLUMN: Request Builder */}
      <div className="space-y-5">
        <div className="bg-slate-900/95 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <h3 className="text-sm font-sans font-bold text-slate-100 flex items-center gap-2">
              <Settings className="w-4.5 h-4.5 text-blue-500" />
              API Request Constructor
            </h3>
            <span className="text-[10px] font-mono font-bold text-slate-500">HTTP CONSOLE</span>
          </div>

          {/* Target Environment Toggle */}
          <div className="space-y-1.5">
            <label className="block text-[11px] text-slate-400 font-mono uppercase font-semibold">
              Target Environment
            </label>
            <div className="bg-slate-950 p-1 rounded-lg border border-slate-850 flex items-center gap-1">
              <button
                type="button"
                onClick={() => setEnvironment('simulated')}
                className={`flex-1 py-1.5 rounded-md text-xs font-medium transition-all cursor-pointer ${
                  environment === 'simulated'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                Simulated API (Local)
              </button>
              <button
                type="button"
                onClick={() => setEnvironment('live')}
                className={`flex-1 py-1.5 rounded-md text-xs font-medium transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  environment === 'live'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Globe className="w-3.5 h-3.5 shrink-0" /> Real Live API (Intelligra)
              </button>
            </div>
            {environment === 'live' && (
              <p className="text-[10px] text-emerald-400 font-mono italic pl-1">
                Routing to base URL: https://dev-api-lock.intelligra.io/api
              </p>
            )}
          </div>

          {/* Selector */}
          <div>
            <label className="block text-[11px] text-slate-400 font-mono uppercase font-semibold mb-1.5">
              Select Simulated Endpoint
            </label>
            <select
              value={selectedEpId}
              onChange={(e) => setSelectedEpId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 font-sans focus:outline-none focus:border-blue-500 transition-all"
            >
              {endpoints.map((ep) => (
                <option key={ep.id} value={ep.id}>
                  {ep.method} {ep.path} ({ep.name})
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-400 mt-2 italic font-sans leading-relaxed pl-1">
              {endpoint.description}
            </p>
          </div>

          {/* Query parameters (GET) */}
          {endpoint.defaultQueryParams && endpoint.defaultQueryParams.length > 0 && (
            <div className="space-y-3">
              <label className="block text-[11px] text-slate-400 font-mono uppercase font-semibold pb-1.5 border-b border-slate-800/40">
                Query Parameters
              </label>
              <div className="space-y-3">
                {endpoint.defaultQueryParams.map((qp) => (
                  <div key={qp.key} className="grid grid-cols-3 gap-3 items-center">
                    <span className="col-span-1 text-xs font-mono font-bold text-indigo-400 flex items-center gap-1">
                      <CornerDownRight className="w-3 h-3 text-slate-600" />
                      {qp.key}
                    </span>
                    <div className="col-span-2">
                      {qp.key === 'debug' ? (
                        <select
                          value={queryParams[qp.key] || 'false'}
                          onChange={(e) => handleFormFieldChange(qp.key, e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                        >
                          <option value="false">false (Normal Flow)</option>
                          <option value="true">true (Trigger Simulated 500 error)</option>
                        </select>
                      ) : (
                        <input
                          type="text"
                          value={queryParams[qp.key] || ''}
                          onChange={(e) => setQueryParams(prev => ({ ...prev, [qp.key]: e.target.value }))}
                          placeholder={qp.description}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-blue-500"
                        />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Request Body (POST) */}
          {endpoint.method === 'POST' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800/40">
                <label className="block text-[11px] text-slate-400 font-mono uppercase font-semibold">
                  Request Payload (Body JSON)
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-500 font-sans">Raw JSON Mode</span>
                  <input
                    type="checkbox"
                    checked={isRawBody}
                    onChange={(e) => setIsRawBody(e.target.checked)}
                    className="w-3.5 h-3.5 accent-blue-500 rounded border-slate-800 focus:ring-0"
                  />
                </div>
              </div>

              {isRawBody ? (
                <textarea
                  value={jsonBody}
                  onChange={(e) => setJsonBody(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-amber-400 font-mono focus:outline-none focus:border-blue-500 min-h-[160px] leading-relaxed"
                />
              ) : (
                <div className="space-y-3 bg-slate-950/40 p-3 rounded-lg border border-slate-800/60 max-h-72 overflow-y-auto">
                  {Object.keys(formFields).map((key) => {
                    const val = formFields[key];
                    return (
                      <div key={key} className="grid grid-cols-3 gap-3 items-center">
                        <span className="col-span-1 text-xs font-mono font-bold text-indigo-400 flex items-center gap-1.5">
                          <CornerDownRight className="w-3 h-3 text-slate-600" />
                          {key}
                        </span>
                        <div className="col-span-2">
                          {key === 'countryCode' ? (
                            <select
                              value={String(val || 'rw')}
                              onChange={(e) => handleFormFieldChange(key, e.target.value)}
                              className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 transition-colors cursor-pointer"
                            >
                              <option value="rw">Rwanda (rw)</option>
                              <option value="tz">Tanzania (tz)</option>
                              <option value="ke">Kenya (ke)</option>
                              <option value="ug">Uganda (ug)</option>
                              <option value="ng">Nigeria (ng)</option>
                              <option value="za">South Africa (za)</option>
                              <option value="gh">Ghana (gh)</option>
                              <option value="et">Ethiopia (et)</option>
                            </select>
                          ) : key === 'date' ? (
                            <div className="flex gap-2">
                              <input
                                ref={dateInputRef}
                                type="date"
                                value={val || ''}
                                onChange={(e) => handleFormFieldChange(key, e.target.value)}
                                className="flex-1 bg-slate-950 border border-slate-850 rounded-lg px-2 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-blue-500 transition-colors"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  try {
                                    dateInputRef.current?.showPicker();
                                  } catch (e) {
                                    dateInputRef.current?.focus();
                                  }
                                }}
                                className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-850 text-slate-300 rounded-lg text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                              >
                                <Calendar className="w-3.5 h-3.5 text-blue-400" />
                                <span>Date format</span>
                              </button>
                            </div>
                          ) : key === 'time' ? (
                            <div className="flex gap-2">
                              <input
                                ref={timeInputRef}
                                type="time"
                                value={val || ''}
                                onChange={(e) => handleFormFieldChange(key, e.target.value)}
                                className="flex-1 bg-slate-950 border border-slate-850 rounded-lg px-2 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-blue-500 transition-colors"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  try {
                                    timeInputRef.current?.showPicker();
                                  } catch (e) {
                                    timeInputRef.current?.focus();
                                  }
                                }}
                                className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-850 text-slate-300 rounded-lg text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                              >
                                <Clock className="w-3.5 h-3.5 text-purple-400" />
                                <span>Time format</span>
                              </button>
                            </div>
                          ) : typeof val === 'boolean' ? (
                            <select
                              value={String(val)}
                              onChange={(e) => handleFormFieldChange(key, e.target.value)}
                              className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2 py-1.5 text-xs text-slate-200 focus:outline-none"
                            >
                              <option value="true">true</option>
                              <option value="false">false</option>
                            </select>
                          ) : val === null ? (
                            <input
                              type="text"
                              value=""
                              onChange={(e) => handleFormFieldChange(key, e.target.value)}
                              placeholder="null (click to set value)"
                              className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2 py-1.5 text-xs text-slate-500 font-mono focus:outline-none"
                            />
                          ) : (
                            <input
                              type="text"
                              value={val}
                              onChange={(e) => handleFormFieldChange(key, e.target.value)}
                              placeholder={`Enter ${key}`}
                              className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none"
                            />
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Execute button */}
          <button
            onClick={handleFireRequest}
            disabled={isLoading}
            className="w-full py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold shadow-md shadow-blue-500/10 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Executing Request...
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" /> Execute Test Request
              </>
            )}
          </button>
        </div>
      </div>

      {/* RIGHT COLUMN: Response Viewer */}
      <div className="space-y-4">
        {/* Dynamic Helpers (If any data generated) */}
        {renderResponseHelpers()}

        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg h-[460px] flex flex-col">
          {/* Header */}
          <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <span className="text-xs font-sans font-bold text-slate-300">Live Response Panel</span>
            {responseStatus !== null && (
              <div className="flex items-center gap-2">
                {responseTime && (
                  <span className="text-[10px] text-slate-500 font-mono">Time: {responseTime}ms</span>
                )}
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono border ${
                  responseStatus >= 200 && responseStatus < 300
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                    : responseStatus >= 400 && responseStatus < 500
                    ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                    : 'bg-red-500/10 text-red-400 border-red-500/20'
                }`}>
                  {responseStatus === 0 ? 'CONNECTION FAILED' : `${responseStatus} ${responseStatus === 200 ? 'OK' : responseStatus === 401 ? 'UNAUTHORIZED' : responseStatus === 404 ? 'NOT FOUND' : responseStatus === 500 ? 'SERVER ERROR' : 'ERROR'}`}
                </span>
              </div>
            )}
          </div>

          {/* Response screen */}
          <div className="flex-1 bg-slate-950 p-4 overflow-y-auto font-mono text-xs text-slate-400 custom-scrollbar relative">
            {responseBody === null ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-700 space-y-2">
                <Play className="w-8 h-8 text-slate-800 animate-pulse" />
                <p className="text-xs font-sans">Ready to execute call...</p>
                <p className="text-[10px] text-slate-800 max-w-xs text-center font-sans">
                  Choose your parameters and click "Execute Test Request" to see simulated output.
                </p>
              </div>
            ) : (
              <div className="space-y-4 select-text">
                {/* Headers visualization */}
                <div>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-1">Response Headers</p>
                  <div className="bg-slate-900/60 p-2.5 rounded border border-slate-900 text-[10px] space-y-0.5">
                    {Object.entries(responseHeaders).map(([k, v]) => (
                      <p key={k}><span className="text-slate-600">{k}:</span> <span className="text-slate-400">{v}</span></p>
                    ))}
                  </div>
                </div>

                {/* Body visualization */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Response JSON Body</p>
                    <button
                      onClick={copyResponse}
                      className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 hover:underline cursor-pointer"
                    >
                      {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Clipboard className="w-3 h-3" />}
                      Copy JSON
                    </button>
                  </div>
                  <pre className={`p-3 rounded border font-mono leading-relaxed overflow-x-auto text-[11px] ${
                    responseStatus === 200 
                      ? 'bg-slate-900/30 text-emerald-400 border-emerald-900/10' 
                      : 'bg-red-950/10 text-red-400 border-red-950/20'
                  }`}>
                    {JSON.stringify(responseBody, null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

    </div>
  );
}
