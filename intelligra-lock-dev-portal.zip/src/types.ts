/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface OnboardingSession {
  sessionId: string;
  username: string;
  countryCode: string;
  msisdn: string;
  serviceProvider: string;
  imei?: string;
  wifiSSID?: string;
  wifiPassword?: string;
  wifiSecType?: string;
  useMobileData: boolean;
  status: 'PENDING' | 'COMPLETED' | 'FAILED';
  createdAt: string;
  completedAt?: string | null;
}

export interface DeviceState {
  imei: string;
  isLocked: boolean;
  status: 'LOCKED' | 'UNLOCKED' | 'PENDING_ONBOARDING';
  countryCode: string;
  lastUpdated: string;
  scheduledLockDate?: string | null;
  scheduledLockTime?: string | null;
  cancelFutureLock?: boolean;
}

export interface ApiLog {
  id: string;
  timestamp: string;
  method: string;
  endpoint: string;
  headers: Record<string, string>;
  requestBody?: any;
  responseStatus: number;
  responseBody: any;
  durationMs: number;
}

export interface Country {
  code: string;
  name: string;
}

export interface EndpointDefinition {
  id: string;
  name: string;
  method: 'GET' | 'POST';
  path: string;
  description: string;
  category: 'Onboarding' | 'Device State';
  defaultHeaders: { key: string; value: string; description: string }[];
  defaultBody?: string;
  defaultQueryParams?: { key: string; value: string; description: string }[];
}
