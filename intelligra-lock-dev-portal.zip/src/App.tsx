/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);

  // Check persistent session on load
  useEffect(() => {
    const token = localStorage.getItem('intelligra_session_token');
    const storedUser = localStorage.getItem('intelligra_session_user');

    if (token && storedUser) {
      try {
        setUser(JSON.parse(storedUser));
        setIsAuthenticated(true);
      } catch (e) {
        // Corrupt cache backup
        localStorage.removeItem('intelligra_session_token');
        localStorage.removeItem('intelligra_session_user');
      }
    }
    setIsInitializing(false);
  }, []);

  const handleLoginSuccess = (token: string, userData: { username: string; role: string }) => {
    localStorage.setItem('intelligra_session_token', token);
    localStorage.setItem('intelligra_session_user', JSON.stringify(userData));
    setUser(userData);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('intelligra_session_token');
    localStorage.removeItem('intelligra_session_user');
    setUser(null);
    setIsAuthenticated(false);
  };

  if (isInitializing) {
    return (
      <div id="loading-fallback" className="min-h-screen bg-slate-950 flex flex-col items-center justify-center font-sans">
        <div className="w-10 h-10 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin mb-4" />
        <p className="text-slate-400 text-xs font-mono animate-pulse">Initializing Gateways...</p>
      </div>
    );
  }

  return (
    <div id="app-root">
      {isAuthenticated && user ? (
        <Dashboard user={user} onLogout={handleLogout} />
      ) : (
        <LoginPage onLoginSuccess={handleLoginSuccess} />
      )}
    </div>
  );
}
